{
	"name":"iewil",
	"version":"2.1",
	"author":"iewilmaestro",
	"author_email":"<purna.iera@gmail.com>",
	"description":"Tool Php Sederhana",
	"classifiers":
		{
			"Programming_Language":"PHP",
			"Operating System":
				[
					"Linux",
					"Windows"
				]
		}
}
