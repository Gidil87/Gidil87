<h2> OK | GAS </h2>

[![Youtobe: iewil](https://img.shields.io/youtube/channel/subscribers/UCvBSqRaT6nsPvtl8m6GaQpg?style=social)](https://youtube.com/c/iewil)
[![Github: iewil](https://img.shields.io/github/followers/iewilmaestro?style=social)](https://github.com/iewilmaestro)
[![Telegram: iewil](https://img.shields.io/badge/Telegram-Iewil-green?style=social&logo=Telegram)](https://t.me/iewil57)
<br>
# TOOL_PHP
```bash
├───CRYPTO
│   ├───Api_Multibot
│   ├───Api_Xevil
│   └───Free
├───IDR
│   └───Free
├───LAIN
└───RUBLE
    └───Free
```

### Instalasi
```php
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install php
$ termux-setup-storage
$ git clone https://github.com/iewilmaestro/TOOL_PHP
$ cd TOOL_PHP
$ php run.php
```

### Manual Update
```php
$ git pull
or
$ git reset --hard
$ git pull
```

![Donation: iewil](https://img.shields.io/badge/💰-Donation-blue?style=flat-square)<br>
![BTC: iewil](https://img.shields.io/badge/BTC-18jswG2t9EZrnHju5dyiYw1yGbkcrTSgJg-blue?style=flat-square&logo=bitcoin)
![Paypal: iewil](https://img.shields.io/badge/Paypal-Purna.iera@gmail.com-blue?style=flat-square&logo=paypal)
![Dana: iewil](https://img.shields.io/badge/Dana-085819008551-blue?style=flat-square&logo=idr)
