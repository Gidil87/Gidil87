<?php
print "Hello World";
?>